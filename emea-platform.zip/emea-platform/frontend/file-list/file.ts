export class File {
  id: string;
  name: string;
  status: FileStatus;
  lastUpdateDate: Date;
  lastUpdatedBy: string;

  constructor(id, name, status, lastUpdateDate, lastUpdatedBy) {
    this.id = id;
    this.name = name;
    this.status = status;
    this.lastUpdatedBy = lastUpdatedBy;
    this.lastUpdateDate = lastUpdateDate;
  }
}


export enum FileStatus {
  WAITING, IN_PROGRESS, DONE
}
