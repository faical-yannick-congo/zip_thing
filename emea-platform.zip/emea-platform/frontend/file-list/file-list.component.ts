import { Component, OnInit } from '@angular/core';
import {CdkDragDrop, moveItemInArray, transferArrayItem} from '@angular/cdk/drag-drop';
import {File, FileStatus} from '../file-list/file';
import {BehaviorSubject} from 'rxjs';

@Component({
  selector: 'app-file-list',
  templateUrl: './file-list.component.html',
  styleUrls: ['./file-list.component.css']
})
export class FileListComponent implements OnInit {

  filesList: BehaviorSubject<File[]>;
  waiting: File[];
  inProgress: File[];
  done: File[];


  constructor() {
  }

  ngOnInit() {
    this.filesList = new BehaviorSubject<File[]>(undefined);
    this.waiting = [];
    this.inProgress = [];
    this.done = [];

    this.filesList.next(
      [
        new File('1', 'File 1', FileStatus.WAITING, '2019-02-11','SAP'),
        new File('2', 'File 2', FileStatus.IN_PROGRESS, '2019-02-11','nazihhas'),
        new File('3', 'File 3', FileStatus.DONE, '2019-02-11','nazihhas'),
        new File('4', 'File 4', FileStatus.DONE, '2019-02-11','ammpumriha')
      ]
    );

    this.dispatchFilesByStatus(this.filesList);
  }

  drop(event: CdkDragDrop<string[]>) {
    //console.log("I'm here");
    if (event.previousContainer === event.container) {
      moveItemInArray(event.container.data, event.previousIndex, event.currentIndex);
    } else {
      transferArrayItem(event.previousContainer.data,
        event.container.data,
        event.previousIndex,
        event.currentIndex);
    }
  }

  private dispatchFilesByStatus(filesList: BehaviorSubject<File[]>) {
    for(let file of filesList.getValue())
    {
      switch (file.status) {
        case FileStatus.WAITING: this.waiting.push(file); break;
        case FileStatus.IN_PROGRESS: this.inProgress.push(file); break;
        case FileStatus.DONE: this.done.push(file); break;
      }
    }
  }
}
