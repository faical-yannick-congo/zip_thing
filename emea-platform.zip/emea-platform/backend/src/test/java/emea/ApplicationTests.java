package emea;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;

import static org.hamcrest.Matchers.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@RunWith(SpringRunner.class)
@SpringBootTest
@AutoConfigureMockMvc
public class ApplicationTests {

	@Autowired
	private MockMvc mockMvc;

	@Autowired
	private AccountRepository accountRepository;

	@Autowired
	private PaymentFileRepository paymentFileRepository;

	@Before
	public void deleteAllBeforeTests() throws Exception {
		accountRepository.deleteAll();
		paymentFileRepository.deleteAll();
	}

	@Test
	public void shouldReturnRepositoryIndex() throws Exception {

		mockMvc.perform(get("/")).andDo(print()).andExpect(status().isOk()).andExpect(
				jsonPath("$._links.account").exists());
	}

	@Test
	public void shouldCreateEntity() throws Exception {
		mockMvc.perform(post("/account").content(
				"{\"email\": \"john.doe@unknown.com\", \"name\": \"John Doe\", \"session\":\"uwu1o2381i2o183h80103mjw8193\"}")).andExpect(
						status().isCreated()).andExpect(
								header().string("Location", containsString("account/")));
	}

	@Test
	public void shouldRetrieveEntity() throws Exception {

		MvcResult mvcResult = mockMvc.perform(post("/account").content(
				"{\"email\": \"john.doe@unknown.com\", \"name\": \"John Doe\", \"session\":\"uwu1o2381i2o183h80103mjw8193\"}")).andExpect(
						status().isCreated()).andReturn();

		String location = mvcResult.getResponse().getHeader("Location");
		mockMvc.perform(get(location)).andExpect(status().isOk()).andExpect(
				jsonPath("$.email").value("john.doe@unknown.com")).andExpect(
						jsonPath("$.session").value("uwu1o2381i2o183h80103mjw8193")).andExpect(
								jsonPath("$.name").value("John Doe"));
	}

	@Test
	public void shouldQueryEntity() throws Exception {

		mockMvc.perform(post("/account").content(
				"{\"email\": \"john.doe@unknown.com\", \"name\": \"John Doe\", \"session\":\"uwu1o2381i2o183h80103mjw8193\"}")).andExpect(
						status().isCreated());

		mockMvc.perform(
				get("/account/search/findByEmail?email={email}", "john.doe@unknown.com")).andExpect(
						status().isOk()).andExpect(jsonPath("$._embedded.account[0].session").value(
						"uwu1o2381i2o183h80103mjw8193")).andExpect(jsonPath("$._embedded.account[0].name").value(
														"John Doe"));
	}

	@Test
	public void shouldUpdateEntity() throws Exception {

		MvcResult mvcResult = mockMvc.perform(post("/account").content(
				"{\"email\": \"john.doe@unknown.com\", \"name\": \"John Doe\", \"session\":\"uwu1o2381i2o183h80103mjw8193\"}")).andExpect(
						status().isCreated()).andReturn();

		String location = mvcResult.getResponse().getHeader("Location");

		mockMvc.perform(put(location).content(
				"{\"email\": \"john.doe@unknown.com\", \"name\": \"John Doe\", \"session\":\"uwu1o2381i2o183h80103mjw8193\"}")).andExpect(
						status().isNoContent());

		mockMvc.perform(get(location)).andExpect(status().isOk()).andExpect(
				jsonPath("$.email").value("john.doe@unknown.com")).andExpect(
						jsonPath("$.session").value("uwu1o2381i2o183h80103mjw8193")).andExpect(
								jsonPath("$.name").value("John Doe"));
	}

	@Test
	public void shouldPartiallyUpdateEntity() throws Exception {

		MvcResult mvcResult = mockMvc.perform(post("/account").content(
				"{\"email\": \"john.doe@unknown.com\", \"name\": \"John Doe\", \"session\":\"uwu1o2381i2o183h80103mjw8193\"}")).andExpect(
						status().isCreated()).andReturn();

		String location = mvcResult.getResponse().getHeader("Location");

		mockMvc.perform(
				patch(location).content("{\"name\": \"John Doe Jr.\"}")).andExpect(
						status().isNoContent());

		mockMvc.perform(get(location)).andExpect(status().isOk()).andExpect(
				jsonPath("$.email").value("john.doe@unknown.com")).andExpect(
						jsonPath("$.session").value("uwu1o2381i2o183h80103mjw8193")).andExpect(
								jsonPath("$.name").value("John Doe Jr."));
	}

	@Test
	public void shouldDeleteEntity() throws Exception {

		MvcResult mvcResult = mockMvc.perform(post("/account").content(
				"{\"email\": \"john.doe@unknown.com\", \"name\": \"John Doe\", \"session\":\"uwu1o2381i2o183h80103mjw8193\"}")).andExpect(
						status().isCreated()).andReturn();

		String location = mvcResult.getResponse().getHeader("Location");
		mockMvc.perform(delete(location)).andExpect(status().isNoContent());

		mockMvc.perform(get(location)).andExpect(status().isNotFound());
	}
}
